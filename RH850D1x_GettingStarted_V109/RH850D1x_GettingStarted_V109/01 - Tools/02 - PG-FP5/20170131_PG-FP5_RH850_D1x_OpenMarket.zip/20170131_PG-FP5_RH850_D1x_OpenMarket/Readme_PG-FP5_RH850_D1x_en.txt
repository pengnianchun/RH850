PG-FP5 V2.15 support Readme Jan 31, 2017

[Introduction]
Thank you for purchasing PG-FP5.
This document mentions about support microcontroller list of PG-FP5 V2.15.
Use preliminary support microcontroller as a preliminary version of the system
for evaluation. Refer to the release note or the user's manual for others.
https://www.renesas.com/pg_fp5

[Formal support microcontroller]
  RH850/D1L: R7F701401, R7F701402, R7F701403, R7F701421, R7F701422, R7F701423
  RH850/D1M: R7F701404, R7F701405, R7F701406, R7F701407, R7F701408, R7F701410, 
             R7F701411, R7F701412, R7F701428, R7F701430, R7F701431, R7F701432

[Preliminary support microcontroller]
  RH850/D1M: R7F701405(WS1.0), R7F701408(WS), R7F701412(WS), R7F701461
  () Stamped version of the available microcontroller

[Attached file]
- Readme(This file)

- Parameter file
  pr5.zip
   R7F701401.pr5 V1.00
   R7F701402.pr5 V1.00
   R7F701403.pr5 V1.00
   R7F701404.pr5 V1.00
   R7F701405.pr5 V1.00
   R7F701406.pr5 V1.00
   R7F701407.pr5 V1.00
   R7F701408.pr5 V1.00
   R7F701410.pr5 V1.00
   R7F701411.pr5 V1.00
   R7F701412.pr5 V1.00
   R7F701421.pr5 V1.00
   R7F701422.pr5 V1.00
   R7F701423.pr5 V1.00
   R7F701428.pr5 V1.00
   R7F701430.pr5 V1.00
   R7F701431.pr5 V1.00
   R7F701432.pr5 V1.00
   R7F701461.pr5 E1.00b
  pr5_1.zip
   R7F701405.pr5 E1.00a (WS1.0)
   R7F701408.pr5 E1.00b (WS)
   R7F701412.pr5 E1.00b (WS)

(Supplement)
  Programming GUI V2.15 *
  Firmware V2.15 *
  FPGA V4 *
  *This file is got from WEB site.
  Refer to the user's manual for installation and usage.
